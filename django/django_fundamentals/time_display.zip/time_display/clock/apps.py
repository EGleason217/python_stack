from django.apps import AppConfig


class ClockConfig(AppConfig):
    name = 'clock'
